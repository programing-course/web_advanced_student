window.addEventListener('DOMContentLoaded', function () {
	//ローディング画面を1.5秒（1500ms）待機してからフェードアウト
	$("#loading").delay(1500).fadeOut('slow');
	//ロゴを1.2秒（1200ms）待機してからフェードアウト
	$("#loading__img").delay(1500).fadeOut('slow');
  });